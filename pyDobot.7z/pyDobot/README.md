# pyDobot

!WORK IN PROGRESS!

An Implementation of a python based interface to the dobot arm. 

It implements the binary interface that is used to talk to the arduino which then sends (proprietary) messages to the controller board. The protocol description can be found here: 

http://dobot.cc/download/developer/Dobot_protocol_en_1.0_beta.pdf

Feel free to use the code, report bugs (and hopefully pull requests). 

A ROS interface is also planned in the future. 


